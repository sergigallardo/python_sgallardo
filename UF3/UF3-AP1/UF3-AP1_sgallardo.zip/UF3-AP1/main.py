from functions import benviguda


def main():
    benviguda()
if __name__ == '__main__':
    main()